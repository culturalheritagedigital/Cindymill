This is a complete CAD model of the Cindymill. Version: 2021_09_22

Cindymill is a DIY CNC milling machine. It is supposed to be a good introduction to the world of milling. 
As you build the machine, you learn how it works. Cindymill is open source, so you can easily adapt it to your needs. 
The components are affordable, but the machine is rigid enough to comfortably mill aluminum (as well as wood and plastic, of course).

Find more info about the project here: http://cindymill.xyz/
The files can be downloaded/forked from Github: https://github.com/culturalheritagedigital/Cindymill

Contact: cindymill@culturalheritage.digital

This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.